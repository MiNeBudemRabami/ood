#include "stdafx.h"
#include "ImageImpl.h"


CImageImpl::CImageImpl()
{
}


CImageImpl::~CImageImpl()
{
}
