#pragma once

class CParagraphImpl
{
public:
	//std::string GetText()const override;
	//void SetText(const std::string& text) override;
};

