#pragma once
class CImageImpl
{
public:
	CImageImpl();
	~CImageImpl();
};

