#pragma once

class CImage
{

};