#include "stdafx.h"
#include "Image.h"