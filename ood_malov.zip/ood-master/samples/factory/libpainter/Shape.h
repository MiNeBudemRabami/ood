#pragma once
class CShape
{
public:
	CShape();
	virtual ~CShape();
};

