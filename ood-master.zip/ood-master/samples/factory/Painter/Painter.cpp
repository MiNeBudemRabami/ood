// Painter.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "../libpainter/Designer.h"

using namespace std;

int main()
{

	//CDesigner designer;

	return 0;
}

