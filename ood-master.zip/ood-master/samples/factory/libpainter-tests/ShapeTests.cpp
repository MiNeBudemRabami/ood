#include "stdafx.h"
#include "../libpainter/Shape.h"
