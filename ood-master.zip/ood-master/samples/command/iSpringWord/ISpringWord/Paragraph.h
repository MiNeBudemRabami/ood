#pragma once
#include <memory>
#include "IParagraph.h"

class CParagraphImpl;

class CParagraph:public IParagraph
{
public:

private:

};

